using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
    public float repeatRate = 2.5f;
    private float timer = 0;
    public float height = 1;
    public GameObject Coin;


    void Update()
    {
        if (timer > repeatRate)
        {
            timer = 0;
            SpawnCoin();
        }

        timer += Time.deltaTime;
    }

    private void SpawnCoin()
    {
        GameObject newPipe = Instantiate(Coin);
        newPipe.transform.position = transform.position + new Vector3(4.5f, Random.Range(-height, height), -1);
        Destroy(newPipe, 10f);

    }
}
