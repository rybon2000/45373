using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    public AudioSource audioSource;
  
    public GameObject loseUI;
    public int points = 0;
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI moneyText;
    public int money = 0;
    public void StartGame()
    {
        Time.timeScale = 1;
        audioSource = FindObjectOfType<AudioSource>();
      
    }

    private void Update()
    {
        moneyText.text = money.ToString();
    }

    private void ShowLoseUI()
    {
        audioSource.Stop();
        loseUI.SetActive(true);
    }

    public void RepeatGame()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("Game");
    }
    public void OnGameOver()
    {
        ShowLoseUI();
        Time.timeScale = 0;
    }

    public void UpdateScore()
    {
        points++;
        scoreText.text = points.ToString();
    }

    public void TakeMoney()
    {
        money++;
    }
}
