using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class MoneyController : MonoBehaviour
{
    public  GameManager gameManager;
 

    private void Start()
    {
       gameManager = FindObjectOfType<GameManager>();

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
           
            gameManager.TakeMoney();
            Destroy(gameObject);
        }
    }
}
