using Newtonsoft.Json.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class SoundsController : MonoBehaviour
{
    public Slider sliderMusic;
    public Slider sliderSFX;
    
    public AudioSource soundtrackMenu;
    public AudioSource soundtrackGame;

    public AudioSource flySFX;
    public AudioSource hittingGroundSFX;
    public AudioSource takeMoneySFX;

    public AudioMixer mixerMusic;
    public AudioMixer mixerSFX;

    const string mixer_Music = "MusicVolume";
    const string mixer_SFX = "SFXVolume";

    private void Start()
    {
        sliderMusic.onValueChanged.AddListener(SetMusicVolume);
        sliderSFX.onValueChanged.AddListener(SetSFXVolume);
        sliderMusic.value = PlayerPrefs.GetFloat(mixer_Music, 0.5f);
    }

    public void SetMusicVolume(float value)
    {
        mixerMusic.SetFloat(mixer_Music, Mathf.Log10(value) *20);
        PlayerPrefs.SetFloat(mixer_Music, value);
    }

    public void SetSFXVolume(float value)
    {
        mixerSFX.SetFloat(mixer_SFX, Mathf.Log10(value) * 20);
        PlayerPrefs.SetFloat(mixer_SFX, value);
    }

    private void OnEnable()
    {
        PlayerPrefs.SetFloat(mixer_Music, sliderMusic.value);
        PlayerPrefs.SetFloat(mixer_SFX, sliderSFX.value);
    }
}
