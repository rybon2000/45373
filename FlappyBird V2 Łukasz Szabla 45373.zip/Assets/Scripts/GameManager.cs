using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    public AudioSource audioSource;
  
    public GameObject loseUI;
    public GameObject playUI;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI bestScoreText;

    public string score;

    public int currentScore = 0;
    public int bestPoints;  
    public int money = 0;

    private void Start()
    {
       bestPoints =  PlayerPrefs.GetInt(score);
    }
    public void StartGame()
    {
        Time.timeScale = 1;
        audioSource = FindObjectOfType<AudioSource>();
      
    }

    private void Update()
    {
        moneyText.text = money.ToString();
        bestScoreText.text = bestPoints.ToString();
        
    }

    private void ShowLoseUI()
    {
        audioSource.Stop();
        loseUI.SetActive(true);
        playUI.SetActive(false);
    }

    public void RepeatGame()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("Game");
    }
    public void OnGameOver()
    {
        ShowLoseUI();
        Time.timeScale = 0;

        if (currentScore > bestPoints)
        {
            bestPoints = currentScore;

            PlayerPrefs.SetInt(score, currentScore);
            PlayerPrefs.Save(); 
        }
        
    }

    public void UpdateScore()
    {
        currentScore++;
        scoreText.text = currentScore.ToString();
    }

    public void TakeMoney()
    {
        money++;
    }

   
}
