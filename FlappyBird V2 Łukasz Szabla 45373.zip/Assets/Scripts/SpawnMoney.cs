using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnMoney : MonoBehaviour
{
    public float repeatRate = 1;
    private float timer = 0;

    public GameObject prefabMoney;
 
    void Update()
    {
        if (timer > repeatRate)
        {
            timer = 0;
            SpawnMoney_();
        }
        timer += Time.deltaTime;
    }

    private void SpawnMoney_()
    {
        GameObject newMoney = Instantiate(prefabMoney);   
        Destroy(newMoney, 2f);
    }
}
